<?php 

	include "consultas.php";


	function pintaCategorias($defecto) {
		// Completar...	
	}
	

	function pintaTablaUsuarios(){
		// Completar...	
	}

		
	function pintaProductos($orden) {
		// Completar...	
	}

?>